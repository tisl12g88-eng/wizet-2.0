package com.example.samsungmusicwidget;
import android.service.notification.NotificationListenerService;import android.service.notification.StatusBarNotification;import android.media.session.*;import android.content.*;import java.util.*;
public class MusicListener extends NotificationListenerService {
 static MusicListener instance; MediaSessionManager manager; MediaSessionManager.OnActiveSessionsChangedListener listener;
 @Override public void onCreate(){super.onCreate();instance=this;manager=(MediaSessionManager)getSystemService(Context.MEDIA_SESSION_SERVICE);listener=s->MusicWidget.refresh(this);try{manager.addOnActiveSessionsChangedListener(listener,new ComponentName(this,MusicListener.class));}catch(Exception ignored){} }
 @Override public void onListenerConnected(){super.onListenerConnected();MusicWidget.refresh(this);}
 @Override public void onNotificationPosted(StatusBarNotification sbn){if(sbn.getPackageName().contains("music"))MusicWidget.refresh(this);}
 @Override public void onNotificationRemoved(StatusBarNotification sbn){if(sbn.getPackageName().contains("music"))MusicWidget.refresh(this);}
 @Override public void onDestroy(){if(manager!=null&&listener!=null)manager.removeOnActiveSessionsChangedListener(listener);instance=null;super.onDestroy();}
 static MediaController controller(Context c){try{MediaSessionManager m=(MediaSessionManager)c.getSystemService(Context.MEDIA_SESSION_SERVICE);List<MediaController> all=m.getActiveSessions(new ComponentName(c,MusicListener.class));for(MediaController mc:all){String pkg=mc.getPackageName();if(pkg.equals("com.sec.android.app.music")||pkg.equals("com.samsung.android.app.music"))return mc;} }catch(Exception ignored){}return null;}
}
