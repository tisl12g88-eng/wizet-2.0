package com.example.samsungmusicwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.widget.RemoteViews;

public class MusicWidget extends AppWidgetProvider {
    static final String ACTION = "com.example.samsungmusicwidget.CONTROL";

    static PendingIntent control(Context context, String operation) {
        Intent intent = new Intent(context, MusicWidget.class).setAction(ACTION).putExtra("op", operation);
        return PendingIntent.getBroadcast(context, operation.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static PendingIntent openMusic(Context context) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage("com.sec.android.app.music");
        if (intent == null) intent = context.getPackageManager().getLaunchIntentForPackage("com.samsung.android.app.music");
        if (intent == null) intent = new Intent(context, SetupActivity.class);
        return PendingIntent.getActivity(context, 777, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        for (int id : manager.getAppWidgetIds(new ComponentName(context, MusicWidget.class))) {
            update(context, manager, id);
        }
    }

    static void update(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget);
        MediaController controller = MusicListener.controller(context);
        MediaMetadata metadata = controller == null ? null : controller.getMetadata();
        String title = metadata == null ? "삼성 뮤직 — 재생을 시작하세요" : metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        views.setTextViewText(R.id.title, title == null ? "삼성 뮤직" : title);
        PlaybackState state = controller == null ? null : controller.getPlaybackState();
        views.setTextViewText(R.id.play,
                state != null && state.getState() == PlaybackState.STATE_PLAYING ? "Ⅱ" : "▶");
        // Framework MediaController does not expose getShuffleMode/getRepeatMode.
        // Display neutral controls rather than fabricating current playback modes.
        views.setTextViewText(R.id.shuffle, "⇄");
        views.setTextViewText(R.id.repeat, "↻");
        views.setOnClickPendingIntent(R.id.root, openMusic(context));
        views.setOnClickPendingIntent(R.id.title, openMusic(context));
        views.setOnClickPendingIntent(R.id.shuffle, control(context, "shuffle"));
        views.setOnClickPendingIntent(R.id.previous, control(context, "previous"));
        views.setOnClickPendingIntent(R.id.play, control(context, "play"));
        views.setOnClickPendingIntent(R.id.next, control(context, "next"));
        views.setOnClickPendingIntent(R.id.repeat, control(context, "repeat"));
        Intent serviceIntent = new Intent(context, QueueService.class)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        serviceIntent.setData(android.net.Uri.parse("widget://queue/" + id));
        views.setRemoteAdapter(R.id.queue, serviceIntent);
        Intent rowIntent = new Intent(context, MusicWidget.class).setAction(ACTION);
        PendingIntent rowPendingIntent = PendingIntent.getBroadcast(context, 999, rowIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        views.setPendingIntentTemplate(R.id.queue, rowPendingIntent);
        manager.updateAppWidget(id, views);
        manager.notifyAppWidgetViewDataChanged(id, R.id.queue);
    }

    private static void tryCustomAction(MediaController controller, String keyword) {
        PlaybackState state = controller.getPlaybackState();
        if (state == null || state.getCustomActions() == null) return;
        for (PlaybackState.CustomAction action : state.getCustomActions()) {
            String name = (action.getAction() + " " + action.getName()).toLowerCase(java.util.Locale.ROOT);
            if (name.contains(keyword)) {
                controller.getTransportControls().sendCustomAction(action.getAction(), Bundle.EMPTY);
                return;
            }
        }
        // No published custom action: launch Samsung Music for its native controls.
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (!ACTION.equals(intent.getAction())) return;
        MediaController controller = MusicListener.controller(context);
        if (controller == null) return;
        String operation = intent.getStringExtra("op");
        if (operation == null) return;
        MediaController.TransportControls transport = controller.getTransportControls();
        switch (operation) {
            case "previous": transport.skipToPrevious(); break;
            case "next": transport.skipToNext(); break;
            case "play":
                PlaybackState state = controller.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) transport.pause();
                else transport.play();
                break;
            case "shuffle":
            case "repeat":
                tryCustomAction(controller, operation);
                break;
            case "song":
                long queueId = intent.getLongExtra("queueId", -1);
                if (queueId >= 0) transport.skipToQueueItem(queueId);
                break;
            default: return;
        }
        refresh(context);
    }
}
