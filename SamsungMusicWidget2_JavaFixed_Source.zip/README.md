Samsung Music Widget v2.5 — performance-focused update.
Changes: 35ms coalesced worker refresh, 30ms session debounce, 220ms fallback, album-art bitmap caching, queue refresh only when queue contents or active row change. Existing accessibility shuffle/repeat behavior unchanged.
