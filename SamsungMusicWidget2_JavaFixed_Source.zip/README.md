# Samsung Music Transparent Widget 2.0

새로 작성한 Android 홈 화면 위젯 프로젝트입니다. Java 17, Android SDK 35, Gradle 8.10.2 / AGP 8.7.3.

## 설치
1. ZIP을 압축 해제하고 **폴더 안의 내용 전체**를 GitHub 저장소 최상위에 올립니다.
2. Actions → Build Samsung Music Widget APK → Run workflow (또는 main에 push).
3. 성공한 실행의 Artifacts에서 SamsungMusicWidget2-APK를 다운로드합니다.
4. APK 설치 후 앱을 한 번 실행하여 **알림 접근 권한**을 허용합니다.
5. 삼성 뮤직에서 음악을 재생한 뒤 홈 화면에서 위젯을 추가합니다.

## 중요 제한
- 100곡을 잘라내는 코드는 없습니다. 단, 삼성 뮤직이 Android MediaSession API를 통해 공개하는 대기열 길이 이상은 읽을 수 없습니다.
- 셔플/반복은 삼성 뮤직이 MediaSession transport controls 명령을 지원하는 경우에만 작동합니다.
- 삼성 뮤직 앱이 실행되지 않거나 외부 제어를 제한하면 일부 기능이 동작하지 않을 수 있습니다.
- APK는 디버그 서명입니다. 기존 설치 앱과 서명/패키지가 다르므로 새 앱으로 설치됩니다.
- Android 11 이상에서는 다른 앱 실행 감지를 위해 package visibility 설정이 필요할 수 있습니다. AndroidManifest에 queries를 추가해 둡니다.
