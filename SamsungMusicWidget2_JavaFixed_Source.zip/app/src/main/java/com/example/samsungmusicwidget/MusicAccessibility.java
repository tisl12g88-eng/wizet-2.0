package com.example.samsungmusicwidget;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Controls Samsung Music through its actual accessible UI, not fake local toggles. */
public class MusicAccessibility extends AccessibilityService {
    private static MusicAccessibility instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String pending;
    private long requestAt;
    private boolean clicked;
    private static final String PREF = "observed_modes";

    static int mode(Context c, String kind) {
        return c.getSharedPreferences(PREF, MODE_PRIVATE).getInt(kind, -1);
    }
    static void request(Context c, String kind) {
        MusicAccessibility service = instance;
        if (service == null) {
            Intent i = new Intent(c, SetupActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
            return;
        }
        service.pending = kind;
        service.requestAt = android.os.SystemClock.uptimeMillis();
        service.clicked = false;
        Intent launch = c.getPackageManager().getLaunchIntentForPackage("com.sec.android.app.music");
        if (launch == null) launch = c.getPackageManager().getLaunchIntentForPackage("com.samsung.android.app.music");
        if (launch != null) { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP); c.startActivity(launch); }
        service.handler.postDelayed(service::tryClick, 550);
        service.handler.postDelayed(service::tryClick, 1300);
        service.handler.postDelayed(service::tryClick, 2400);
    }
    @Override protected void onServiceConnected() { instance = this; }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || !MusicListener.isSamsungMusic(String.valueOf(e.getPackageName()))) return;
        observe();
        if (pending != null) handler.postDelayed(this::tryClick, 160);
    }
    @Override public void onInterrupt() { }
    private void observe() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !MusicListener.isSamsungMusic(String.valueOf(root.getPackageName()))) return;
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0);
        SharedPreferences.Editor edit = getSharedPreferences(PREF, MODE_PRIVATE).edit();
        boolean changed = false;
        for (AccessibilityNodeInfo n : nodes) {
            String d = label(n);
            if (isShuffle(d)) {
                int state = inferShuffle(d, n);
                if (state >= 0) { edit.putInt("shuffle", state); changed = true; }
            } else if (isRepeat(d)) {
                int state = inferRepeat(d, n);
                if (state >= 0) { edit.putInt("repeat", state); changed = true; }
            }
        }
        if (changed) { edit.apply(); MusicWidget.refresh(this); }
    }
    private void tryClick() {
        if (pending == null || clicked) return;
        if (android.os.SystemClock.uptimeMillis() - requestAt > 4000) { pending = null; return; }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || !MusicListener.isSamsungMusic(String.valueOf(root.getPackageName()))) return;
        List<AccessibilityNodeInfo> nodes = new ArrayList<>(); collect(root, nodes, 0);
        for (AccessibilityNodeInfo n : nodes) {
            String d = label(n);
            if (("shuffle".equals(pending) && isShuffle(d)) || ("repeat".equals(pending) && isRepeat(d))) {
                AccessibilityNodeInfo target = n;
                while (target != null && !target.isClickable()) target = target.getParent();
                if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    clicked = true; pending = null;
                    handler.postDelayed(this::observe, 350);
                    handler.postDelayed(this::observe, 900);
                    return;
                }
            }
        }
    }
    private static void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 25 || out.size() > 500) return;
        out.add(n);
        for (int i=0;i<n.getChildCount();i++) collect(n.getChild(i), out, depth+1);
    }
    private static String label(AccessibilityNodeInfo n) {
        CharSequence desc=n.getContentDescription();
        CharSequence text=n.getText();
        return ((desc==null?"":desc.toString())+" "+(text==null?"":text.toString())).toLowerCase(Locale.ROOT);
    }
    private static boolean isShuffle(String s) { return s.contains("shuffle") || s.contains("셔플") || s.contains("무작위") || s.contains("임의 재생"); }
    private static boolean isRepeat(String s) { return s.contains("repeat") || s.contains("반복"); }
    private static int inferShuffle(String s, AccessibilityNodeInfo n) {
        if (s.contains("off") || s.contains("끔") || s.contains("해제") || s.contains("사용 안") || s.contains("비활성")) return 0;
        if (s.contains("on") || s.contains("켬") || s.contains("설정") || s.contains("활성")) return 1;
        if (n.isCheckable()) return n.isChecked()?1:0;
        return -1;
    }
    private static int inferRepeat(String s, AccessibilityNodeInfo n) {
        if (s.contains("one") || s.contains("single") || s.contains("한 곡") || s.contains("1곡") || s.contains("한곡")) return 1;
        if (s.contains("all") || s.contains("전체") || s.contains("모두")) return 2;
        if (s.contains("off") || s.contains("끔") || s.contains("해제") || s.contains("사용 안")) return 0;
        return -1;
    }
}
