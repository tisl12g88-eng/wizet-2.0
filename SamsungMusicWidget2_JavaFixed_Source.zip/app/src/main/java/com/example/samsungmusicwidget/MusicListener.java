package com.example.samsungmusicwidget;

import android.content.ComponentName;
import android.content.Context;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.media.MediaMetadata;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.List;

public class MusicListener extends NotificationListenerService {
    private MediaSessionManager manager;
    private MediaController observed;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable refreshTask = () -> MusicWidget.refresh(MusicListener.this);
    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState state) { scheduleRefresh(); }
        @Override public void onMetadataChanged(MediaMetadata metadata) { scheduleRefresh(); }
        @Override public void onQueueChanged(List<android.media.session.MediaSession.QueueItem> queue) { scheduleRefresh(); }
        @Override public void onQueueTitleChanged(CharSequence title) { scheduleRefresh(); }
        @Override public void onExtrasChanged(android.os.Bundle extras) { scheduleRefresh(); }
        @Override public void onSessionDestroyed() { main.post(() -> { bindSession(); scheduleRefresh(); }); }
    };
    private final MediaSessionManager.OnActiveSessionsChangedListener sessionListener = sessions -> {
        main.post(() -> { bindSession(); scheduleRefresh(); });
    };
    private void scheduleRefresh() { main.removeCallbacks(refreshTask); main.postDelayed(refreshTask, 120); }
    private void bindSession() {
        MediaController next = controller(this);
        if (observed != null && next != null && observed.getSessionToken().equals(next.getSessionToken())) return;
        if (observed != null) observed.unregisterCallback(callback);
        observed = next;
        if (observed != null) observed.registerCallback(callback, main);
    }
    @Override public void onCreate() {
        super.onCreate();
        manager = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
    }
    @Override public void onListenerConnected() {
        super.onListenerConnected();
        try { manager.addOnActiveSessionsChangedListener(sessionListener, new ComponentName(this, MusicListener.class), main); }
        catch (Exception ignored) { }
        bindSession(); scheduleRefresh();
    }
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (isSamsungMusic(sbn.getPackageName())) { bindSession(); scheduleRefresh(); }
    }
    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        if (isSamsungMusic(sbn.getPackageName())) { bindSession(); scheduleRefresh(); }
    }
    @Override public void onListenerDisconnected() {
        if (observed != null) { observed.unregisterCallback(callback); observed = null; }
        try { manager.removeOnActiveSessionsChangedListener(sessionListener); } catch (Exception ignored) { }
        super.onListenerDisconnected();
    }
    @Override public void onDestroy() {
        main.removeCallbacks(refreshTask);
        if (observed != null) observed.unregisterCallback(callback);
        try { manager.removeOnActiveSessionsChangedListener(sessionListener); } catch (Exception ignored) { }
        super.onDestroy();
    }
    static boolean isSamsungMusic(String pkg) {
        return "com.sec.android.app.music".equals(pkg) || "com.samsung.android.app.music".equals(pkg);
    }
    static MediaController controller(Context context) {
        try {
            MediaSessionManager m = (MediaSessionManager) context.getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> sessions = m.getActiveSessions(new ComponentName(context, MusicListener.class));
            for (MediaController session : sessions) if (isSamsungMusic(session.getPackageName())) return session;
        } catch (Exception ignored) { }
        return null;
    }
}
