package com.example.samsungmusicwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.List;

public class MusicWidget extends AppWidgetProvider {
    static final String ACTION = "com.example.samsungmusicwidget.CONTROL";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    static PendingIntent control(Context c, String op) {
        Intent i = new Intent(c, MusicWidget.class).setAction(ACTION).putExtra("op", op);
        return PendingIntent.getBroadcast(c, op.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static PendingIntent openMusic(Context c) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage("com.sec.android.app.music");
        if (i == null) i = c.getPackageManager().getLaunchIntentForPackage("com.samsung.android.app.music");
        if (i == null) i = new Intent(c, SetupActivity.class);
        return PendingIntent.getActivity(c, 777, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) update(c, m, id); }
    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, MusicWidget.class))) update(c, m, id);
    }
    static void update(Context c, AppWidgetManager m, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        MediaController mc = MusicListener.controller(c);
        MediaMetadata md = mc == null ? null : mc.getMetadata();
        String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
        v.setTextViewText(R.id.title, title == null || title.isEmpty() ? "삼성 뮤직 — 재생을 시작하세요" : title);
        PlaybackState state = mc == null ? null : mc.getPlaybackState();
        boolean playing = state != null && (state.getState() == PlaybackState.STATE_PLAYING || state.getState() == PlaybackState.STATE_BUFFERING);
        v.setImageViewResource(R.id.play, playing ? R.drawable.ic_pause : R.drawable.ic_play);
        int shuffle = readMode(mc, "shuffle");
        int repeat = readMode(mc, "repeat");
        v.setImageViewResource(R.id.shuffle, shuffle == 1 ? R.drawable.ic_shuffle_on : R.drawable.ic_shuffle);
        v.setImageViewResource(R.id.repeat, repeat == 1 ? R.drawable.ic_repeat_one : repeat == 2 ? R.drawable.ic_repeat_on : R.drawable.ic_repeat);
        List<MediaSession.QueueItem> queue = mc == null ? null : mc.getQueue();
        v.setViewVisibility(R.id.hint, queue == null || queue.isEmpty() ? android.view.View.VISIBLE : android.view.View.GONE);
        v.setOnClickPendingIntent(R.id.title, openMusic(c));
        v.setOnClickPendingIntent(R.id.shuffle, control(c, "shuffle"));
        v.setOnClickPendingIntent(R.id.previous, control(c, "previous"));
        v.setOnClickPendingIntent(R.id.play, control(c, "play"));
        v.setOnClickPendingIntent(R.id.next, control(c, "next"));
        v.setOnClickPendingIntent(R.id.repeat, control(c, "repeat"));
        Intent si = new Intent(c, QueueService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        si.setData(Uri.parse("widget://queue/" + id));
        v.setRemoteAdapter(R.id.queue, si);
        Intent row = new Intent(c, MusicWidget.class).setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(c, 999, row, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        v.setPendingIntentTemplate(R.id.queue, pi);
        m.updateAppWidget(id, v);
        m.notifyAppWidgetViewDataChanged(id, R.id.queue);
    }
    // Android framework MediaController does not expose standard shuffle/repeat setters.
    // Only dispatch a custom action explicitly advertised by the active music session.
    private static void sendSupportedMode(MediaController mc, String kind) {
        PlaybackState state = mc.getPlaybackState();
        if (state == null || state.getCustomActions() == null) return;
        for (PlaybackState.CustomAction action : state.getCustomActions()) {
            String id = action.getAction();
            if (id == null) continue;
            String lower = id.toLowerCase(java.util.Locale.ROOT);
            if (lower.contains(kind)) {
                mc.getTransportControls().sendCustomAction(id, null);
                return;
            }
        }
    }
    // Session-specific extras are optional; never pretend an unknown mode is enabled.
    private static int readMode(MediaController mc, String kind) {
        if (mc == null) return 0;
        Bundle extras = mc.getExtras();
        if (extras == null) return 0;
        for (String key : extras.keySet()) {
            if (key.toLowerCase(java.util.Locale.ROOT).contains(kind)) {
                Object value = extras.get(key);
                if (value instanceof Integer) return (Integer) value;
                if (value instanceof Boolean) return ((Boolean) value) ? 1 : 0;
            }
        }
        return 0;
    }
    @Override public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (!ACTION.equals(i.getAction())) return;
        MediaController mc = MusicListener.controller(c);
        if (mc == null) return;
        String op = i.getStringExtra("op");
        if (op == null) return;
        MediaController.TransportControls t = mc.getTransportControls();
        switch (op) {
            case "previous": t.skipToPrevious(); break;
            case "next": t.skipToNext(); break;
            case "play":
                PlaybackState state = mc.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play();
                break;
            case "shuffle":
                sendSupportedMode(mc, "shuffle");
                break;
            case "repeat":
                sendSupportedMode(mc, "repeat");
                break;
            case "song":
                long queueId = i.getLongExtra("queueId", -1);
                if (queueId >= 0) t.skipToQueueItem(queueId);
                break;
        }
        // Transport controls are asynchronous: refresh again after Samsung Music acknowledges the command.
        refresh(c);
        Context app = c.getApplicationContext();
        MAIN.postDelayed(() -> refresh(app), 450);
    }
}
