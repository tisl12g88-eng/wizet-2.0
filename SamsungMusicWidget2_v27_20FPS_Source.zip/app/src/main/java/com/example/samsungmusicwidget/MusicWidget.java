package com.example.samsungmusicwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.graphics.BitmapFactory;
import java.io.InputStream;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MusicWidget extends AppWidgetProvider {
    static final String ACTION = "com.example.samsungmusicwidget.CONTROL";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Object LOCK = new Object();
    private static boolean scheduled;
    private static boolean forceNext;
    private static boolean hasQueueSnapshot;
    private static long lastQueueSignature;
    private static long lastActiveQueueId = Long.MIN_VALUE;
    private static String cachedArtKey;
    private static Bitmap cachedArt;
    private static boolean artCached;
    private static volatile Context APP_CONTEXT;
    // RemoteViews cannot host a continuously running custom marquee view.
    // Animate only the title bitmap, leaving the queue and playback controls untouched.
    private static final long MARQUEE_FRAME_MS = 50L;
    private static final float MARQUEE_SPEED_DP = 1.4f;
    private static String marqueeTitle = "";
    private static int marqueeOffsetPx;
    private static int marqueeCyclePx;
    private static boolean marqueeRunning;
    private static final Runnable MARQUEE_TICK = new Runnable() {
        @Override public void run() {
            final Context app = APP_CONTEXT;
            if (app == null || !marqueeRunning) return;
            WORKER.execute(() -> {
                if (!marqueeRunning) return;
                AppWidgetManager manager = AppWidgetManager.getInstance(app);
                int[] ids = manager.getAppWidgetIds(new ComponentName(app, MusicWidget.class));
                if (ids.length == 0) { marqueeRunning = false; return; }
                marqueeOffsetPx += Math.max(1, Math.round(MARQUEE_SPEED_DP * app.getResources().getDisplayMetrics().density));
                if (marqueeCyclePx > 0) marqueeOffsetPx %= marqueeCyclePx;
                for (int widgetId : ids) {
                    RemoteViews partial = new RemoteViews(app.getPackageName(), R.layout.widget);
                    partial.setImageViewBitmap(R.id.title, drawTitle(app, manager, widgetId, marqueeTitle, marqueeOffsetPx));
                    manager.partiallyUpdateAppWidget(widgetId, partial);
                }
                if (marqueeRunning) MAIN.postDelayed(this, MARQUEE_FRAME_MS);
            });
        }
    };
    private static final Runnable FLUSH = () -> WORKER.execute(() -> {
        boolean force;
        synchronized (LOCK) { scheduled = false; force = forceNext; forceNext = false; }
        refreshNow(APP_CONTEXT, force);
    });
    static void scheduleRefresh(Context c, boolean force) {
        APP_CONTEXT = c.getApplicationContext();
        synchronized (LOCK) {
            forceNext |= force;
            if (scheduled) MAIN.removeCallbacks(FLUSH);
            scheduled = true;
        }
        MAIN.postDelayed(FLUSH, 35);
    }
    static PendingIntent control(Context c, String op) {
        Intent i = new Intent(c, MusicWidget.class).setAction(ACTION).putExtra("op", op);
        return PendingIntent.getBroadcast(c, op.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static PendingIntent openMusic(Context c) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage("com.sec.android.app.music");
        if (i == null) i = c.getPackageManager().getLaunchIntentForPackage("com.samsung.android.app.music");
        if (i == null) i = new Intent(c, SetupActivity.class);
        return PendingIntent.getActivity(c, 777, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { scheduleRefresh(c, true); }
    static void refresh(Context c) { scheduleRefresh(c, false); }
    private static void refreshNow(Context c, boolean force) {
        if (c == null) return;
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, MusicWidget.class));
        if (ids.length == 0) return;
        MediaController mc = MusicListener.controller(c);
        List<MediaSession.QueueItem> queue = mc == null ? null : mc.getQueue();
        PlaybackState state = mc == null ? null : mc.getPlaybackState();
        long activeId = state == null ? Long.MIN_VALUE : state.getActiveQueueItemId();
        long signature = queueSignature(queue);
        boolean queueChanged = force || !hasQueueSnapshot || signature != lastQueueSignature || activeId != lastActiveQueueId;
        hasQueueSnapshot = true;
        lastQueueSignature = signature;
        lastActiveQueueId = activeId;
        String title = mc == null || mc.getMetadata() == null ? null : mc.getMetadata().getString(MediaMetadata.METADATA_KEY_TITLE);
        title = title == null || title.isEmpty() ? "삼성 뮤직 — 재생을 시작하세요" : title;
        boolean changed = !title.equals(marqueeTitle);
        if (changed) { marqueeTitle = title; marqueeOffsetPx = 0; }
        boolean longTitle = false;
        for (int id : ids) {
            update(c, m, id, mc, queue, state, queueChanged);
            if (isLongTitle(c, m, id, title)) longTitle = true;
        }
        marqueeRunning = longTitle;
        MAIN.removeCallbacks(MARQUEE_TICK);
        if (longTitle) MAIN.postDelayed(MARQUEE_TICK, MARQUEE_FRAME_MS);
    }
    private static long queueSignature(List<MediaSession.QueueItem> queue) {
        if (queue == null) return 0;
        long hash = 1125899906842597L;
        hash = hash * 31 + queue.size();
        for (MediaSession.QueueItem item : queue) {
            hash = hash * 31 + item.getQueueId();
            if (item.getDescription() != null) {
                hash = hash * 31 + Objects.hashCode(item.getDescription().getTitle());
                hash = hash * 31 + Objects.hashCode(item.getDescription().getSubtitle());
            }
        }
        return hash;
    }
    static void update(Context c, AppWidgetManager m, int id, MediaController mc,
                       List<MediaSession.QueueItem> queue, PlaybackState state, boolean queueChanged) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        MediaMetadata md = mc == null ? null : mc.getMetadata();
        String title = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_TITLE);
        title = title == null || title.isEmpty() ? "삼성 뮤직 — 재생을 시작하세요" : title;
        String artist = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ARTIST);
        v.setTextViewText(R.id.artist, artist == null ? "" : artist);
        v.setImageViewBitmap(R.id.title, drawTitle(c, m, id, title, marqueeOffsetPx));
        v.setContentDescription(R.id.title, title);
        setAlbumArt(c, v, md);
        boolean playing = state != null && (state.getState() == PlaybackState.STATE_PLAYING || state.getState() == PlaybackState.STATE_BUFFERING);
        v.setImageViewResource(R.id.play, playing ? R.drawable.ic_pause : R.drawable.ic_play);
        int shuffle = MusicAccessibility.mode(c, "shuffle");
        int repeat = MusicAccessibility.mode(c, "repeat");
        v.setImageViewResource(R.id.shuffle, shuffle == 1 ? R.drawable.ic_shuffle_on : R.drawable.ic_shuffle);
        v.setImageViewResource(R.id.repeat, repeat == 1 ? R.drawable.ic_repeat_one : repeat == 2 ? R.drawable.ic_repeat_on : R.drawable.ic_repeat);
        v.setViewVisibility(R.id.hint, queue == null || queue.isEmpty() ? android.view.View.VISIBLE : android.view.View.GONE);
        v.setOnClickPendingIntent(R.id.title, openMusic(c));
        v.setOnClickPendingIntent(R.id.shuffle, control(c, "shuffle"));
        v.setOnClickPendingIntent(R.id.previous, control(c, "previous"));
        v.setOnClickPendingIntent(R.id.play, control(c, "play"));
        v.setOnClickPendingIntent(R.id.next, control(c, "next"));
        v.setOnClickPendingIntent(R.id.repeat, control(c, "repeat"));
        Intent si = new Intent(c, QueueService.class).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
        si.setData(Uri.parse("widget://queue/" + id));
        v.setRemoteAdapter(R.id.queue, si);
        Intent row = new Intent(c, MusicWidget.class).setAction(ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(c, 999, row, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
        v.setPendingIntentTemplate(R.id.queue, pi);
        m.updateAppWidget(id, v);
        if (queueChanged) m.notifyAppWidgetViewDataChanged(id, R.id.queue);
    }
    private static Paint titlePaint(Context c) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        paint.setColor(android.graphics.Color.WHITE);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 18, c.getResources().getDisplayMetrics()));
        return paint;
    }
    private static int titleWidth(Context c, AppWidgetManager m, int id) {
        android.os.Bundle options = m.getAppWidgetOptions(id);
        int widgetDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 300);
        if (widgetDp < 120) widgetDp = 300;
        float density = c.getResources().getDisplayMetrics().density;
        // Root 16dp + album 56dp + title container 12dp.
        return Math.max(80, Math.round((widgetDp - 84) * density));
    }
    private static boolean isLongTitle(Context c, AppWidgetManager m, int id, String title) {
        return titlePaint(c).measureText(title) > titleWidth(c, m, id);
    }
    private static Bitmap drawTitle(Context c, AppWidgetManager m, int id, String title, int offset) {
        Paint paint = titlePaint(c);
        float density = c.getResources().getDisplayMetrics().density;
        int width = titleWidth(c, m, id);
        int height = Math.max(1, Math.round(27 * density));
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        float textWidth = paint.measureText(title);
        float baseline = (height - (paint.ascent() + paint.descent())) / 2f;
        if (textWidth <= width) {
            canvas.drawText(title, 0, baseline, paint);
        } else {
            float gap = 64 * density;
            int cycle = Math.max(1, Math.round(textWidth + gap));
            marqueeCyclePx = cycle;
            float x = -(offset % cycle);
            canvas.drawText(title, x, baseline, paint);
            canvas.drawText(title, x + cycle, baseline, paint);
        }
        return bitmap;
    }
    private static void setAlbumArt(Context c, RemoteViews v, MediaMetadata md) {
        Bitmap source = md == null ? null : md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (source == null && md != null) source = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
        String uri = md == null ? null : md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI);
        if ((uri == null || uri.isEmpty()) && md != null) uri = md.getString(MediaMetadata.METADATA_KEY_ART_URI);
        // A new bitmap identity invalidates the cache even when the song title is unchanged.
        String key = md == null ? "none" : String.valueOf(md.getString(MediaMetadata.METADATA_KEY_MEDIA_ID))
                + "|" + md.getString(MediaMetadata.METADATA_KEY_TITLE)
                + "|" + md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                + "|" + md.getString(MediaMetadata.METADATA_KEY_ALBUM)
                + "|" + uri + "|" + (source == null ? 0 : System.identityHashCode(source));
        if (!artCached || !key.equals(cachedArtKey)) {
            Bitmap art = source;
            if (art == null && uri != null && !uri.isEmpty()) {
                try (InputStream stream = c.getContentResolver().openInputStream(Uri.parse(uri))) {
                    if (stream != null) {
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inSampleSize = 4;
                        art = BitmapFactory.decodeStream(stream, null, options);
                    }
                } catch (Exception ignored) { }
            }
            if (art != null) {
                int width = art.getWidth(), height = art.getHeight();
                if (width > 256 || height > 256) {
                    float ratio = Math.min(256f / width, 256f / height);
                    art = Bitmap.createScaledBitmap(art, Math.max(1, Math.round(width * ratio)),
                            Math.max(1, Math.round(height * ratio)), true);
                }
            }
            cachedArt = art;
            cachedArtKey = key;
            artCached = true;
        }
        if (cachedArt != null) v.setImageViewBitmap(R.id.album_art, cachedArt);
        else v.setImageViewResource(R.id.album_art, R.drawable.ic_album_placeholder);
    }
    // Android framework MediaController does not expose standard shuffle/repeat setters.
    // Only dispatch a custom action explicitly advertised by the active music session.
    private static void sendSupportedMode(MediaController mc, String kind) {
        PlaybackState state = mc.getPlaybackState();
        if (state == null || state.getCustomActions() == null) return;
        for (PlaybackState.CustomAction action : state.getCustomActions()) {
            String id = action.getAction();
            if (id == null) continue;
            String lower = id.toLowerCase(java.util.Locale.ROOT);
            if (lower.contains(kind)) {
                mc.getTransportControls().sendCustomAction(id, null);
                return;
            }
        }
    }
    // Session-specific extras are optional; never pretend an unknown mode is enabled.
    private static int readMode(MediaController mc, String kind) {
        if (mc == null) return 0;
        Bundle extras = mc.getExtras();
        if (extras == null) return 0;
        for (String key : extras.keySet()) {
            if (key.toLowerCase(java.util.Locale.ROOT).contains(kind)) {
                Object value = extras.get(key);
                if (value instanceof Integer) return (Integer) value;
                if (value instanceof Boolean) return ((Boolean) value) ? 1 : 0;
            }
        }
        return 0;
    }
    @Override public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (!ACTION.equals(i.getAction())) return;
        MediaController mc = MusicListener.controller(c);
        if (mc == null && !"shuffle".equals(i.getStringExtra("op")) && !"repeat".equals(i.getStringExtra("op"))) return;
        String op = i.getStringExtra("op");
        if (op == null) return;
        MediaController.TransportControls t = mc == null ? null : mc.getTransportControls();
        switch (op) {
            case "previous": t.skipToPrevious(); break;
            case "next": t.skipToNext(); break;
            case "play":
                PlaybackState state = mc.getPlaybackState();
                if (state != null && state.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play();
                break;
            case "shuffle":
                MusicAccessibility.request(c, "shuffle");
                break;
            case "repeat":
                MusicAccessibility.request(c, "repeat");
                break;
            case "song":
                long queueId = i.getLongExtra("queueId", -1);
                if (queueId >= 0) t.skipToQueueItem(queueId);
                break;
        }
        // Transport controls are asynchronous: refresh again after Samsung Music acknowledges the command.
        // Session callbacks deliver the authoritative state. A single fallback handles
        // players that do not publish callbacks promptly.
        refresh(c);
        Context app = c.getApplicationContext();
        MAIN.postDelayed(() -> refresh(app), 220);
    }
}
