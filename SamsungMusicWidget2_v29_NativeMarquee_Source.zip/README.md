v2.9 native TextView marquee experiment. No bitmap frame updates. Native One UI widget-host marquee support varies. Pause sends setSelected(false) and resets title text.
